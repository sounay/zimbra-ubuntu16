# Install-Zimbra-mail-server-ubuntu
Install Zimbra mail server on ubuntu

Download files and run below commands

> `chmod +x install-zimbra-ubuntu.sh`

> `./install-zimbra-ubuntu.sh yourdomain.com 192.168.0.15 Zimbra123`

For Take Backup of zimbra

> `chmod +x zimbra-backup.sh`

> `./zimbra-backup.sh -a`
